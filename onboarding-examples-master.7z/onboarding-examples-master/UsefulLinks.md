# Подборка ссылок на полезные документы

[Записи демонстраций нового функционала Платформы](https://confluence.bftcom.com/pages/viewpage.action?pageId=183823542)

[Прикладная разработка](https://confluence.bftcom.com/pages/viewpage.action?pageId=223357219)

[Проектные документы ЕЦП](http://hq-ib-spp-01:33033/ecp_mintrud/DocLib/Forms/AllItems.aspx)

[Информация о контурах и конфиги для подключения к ним](https://confluence.bftcom.com/pages/viewpage.action?pageId=244183648)

[Справочники и классификаторы](https://confluence.bftcom.com/pages/viewpage.action?pageId=153778252)

[Разные инструкции для разработчиков](https://confluence.bftcom.com/pages/viewpage.action?pageId=191345801)

[Настройка окружения и запуск приложения](https://confluence.bftcom.com/pages/viewpage.action?pageId=186647539)

[Сервисы dev-стенда](https://confluence.bftcom.com/pages/viewpage.action?pageId=173039554)

[План погружения нового сотрудника (Реестры)](https://confluence.bftcom.com/pages/viewpage.action?pageId=262105774)

[Записи встреч с командами разработки Платформенных сервисов](http://hq-ib-spp-01:33033/ecp_mintrud/DocLib/Forms/AllItems.aspx?RootFolder=%2Fecp%5Fmintrud%2FDocLib%2F03%20%D0%92%D1%8B%D0%BF%D0%BE%D0%BB%D0%BD%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%BF%D1%80%D0%BE%D0%B5%D0%BA%D1%82%D0%B0%2F2%20%D0%9E%D1%87%D0%B5%D1%80%D0%B5%D0%B4%D1%8C%20%D0%95%D0%A6%D0%9F%2F%D0%94%D1%80%D1%83%D0%B3%D0%BE%D0%B5%2F%D0%97%D0%B0%D0%BF%D0%B8%D1%81%D0%B8%20%D0%B2%D1%81%D1%82%D1%80%D0%B5%D1%87)

## Телеграм каналы
Их тьма )
Попроси тимлида (или линейного руководителя) подписать тебя на все необходимые.
