# Руководство по деплою приложений 

Пока все просто - обращайтесь к прикрепленному к команде devops-инженеру ) 

Регламент взаимодействия с DevOps командой
https://confluence.bftcom.com/pages/viewpage.action?pageId=272358896


FAQ по CI/CD
https://confluence.bftcom.com/pages/viewpage.action?pageId=235931410