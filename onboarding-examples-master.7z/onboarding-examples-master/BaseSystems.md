## Базовые АС

#### Электронная почта
[owa.bftcom.com](https://owa.bftcom.com)  
Логин/пароль - почта / доменный пароль

#### Service (Единое окно поддержки)
Доброжелательная и классная поддержка по всем техническим вопросам.  
Чтобы отправить запрос напишите письмо [service@bftcom.com](mailto:service@bftcom.com)  
Отслеживать задачи можно в jira

#### Gitlab
https://gitlab.bft.local/   
Логин/пароль - доменные  
Возможно понадобится создать заявку на получение необходимых прав на репозитории, по аналогии с   
https://srv-platformas.bft.local/browse/PS-4605   
https://srv-platformas.bft.local/browse/PS-4681

https://confluence.bftcom.com/pages/viewpage.action?pageId=236706465

#### Jira
https://srv-ecp-jira-01.bft.local

#### Confluence
https://confluence.bftcom.com/

#### ADS Configurator
http://srv-ice-tmc-d11.bft.local:8082/app/#/objects/AppModule:apso  
Логин/пароль - спроси у тимлида  
Основная система для создания шаблонов благородных сервисов

Подробнее о создании агрегатных сервисов (и физ моделей) см  [DDL.md](DDL.md)

#### Стенд НСИ
http://10.169.8.96:8080/app/#/records/Dict:TerritorialDivisions  
Логин - ECP_RO  
Пароль - спроси у тимлида

