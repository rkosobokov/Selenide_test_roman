
# Сертификаты

Сертификат есть в корне этого репозитория.   
Подробнее см [Переезд на gitlab.bft.local](https://confluence.bftcom.com/pages/viewpage.action?pageId=226022320)


## Мини инструкция
Чтобы добавить в JDK сертификат для работы с внутренним сервисом нужно:

### 1. Получить этот сертификат
```shell
keytool -printcert -sslserver gitlab.bft.local -rfc > bft_gitlab.pem
```

### 2. Найти файл cacerts
Это trusted store (доверенное хранилище) сертификатов для JDK. Соответственно для каждой версии JDK он свой. 
Например ищем их командой: 
```shell
find / -name cacerts
```

### 3. Добавить сертификат в cacerts
```shell
keytool -importcert -file ./bft_gitlab.pem -keystore <ПУТЬ ДО ФАЙЛА>
```
где <ПУТЬ ДО ФАЙЛА>, результат выполнения п2, в соответствии с необходимой версией JDK (см названия родительских каталогов).

При выполнении этой команды будет запрошен пароль. Стандартный:
```text
changeit
```
